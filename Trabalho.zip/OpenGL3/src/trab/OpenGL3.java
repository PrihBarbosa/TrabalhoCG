package trab;

import java.nio.FloatBuffer;

import javax.swing.JFrame;

import com.jogamp.common.nio.Buffers;
import com.jogamp.opengl.GL;
import com.jogamp.opengl.GL3;
import com.jogamp.opengl.GLAutoDrawable;
import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLEventListener;
import com.jogamp.opengl.GLException;
import com.jogamp.opengl.GLProfile;
import com.jogamp.opengl.awt.GLJPanel;
import com.jogamp.opengl.util.GLBuffers;
import com.jogamp.opengl.util.glsl.ShaderCode;
import com.jogamp.opengl.util.glsl.ShaderProgram;
import java.util.Scanner;

public class OpenGL3 implements GLEventListener {
    
    private Opcoes op = new Opcoes();
    String name;  /*nome usado nos comandos*/
    float x, y, z, ang;  /*(x,y,z)eixos, (x,y,z)rgb, x(k-coef. de reflexão), ang(ângulo)*/
    float mat[] = new float[16];
    Scanner entrada = new Scanner(System.in);
    
    private ShaderProgram shaderProgram;
    private ShaderCode vertexShader;
    private ShaderCode fragmentShader;

    private int[] vao = new int[2];
    private int[] vbo = new int[2];

    private int projMatrixLoc, viewMatrixLoc, modelMatrixLoc;

    // storage for Matrices
    private float projMatrix[] = new float[16];
    private float viewMatrix[] = new float[16];
    private float modelMatrix[] = new float[16];
    
    Cube cube;
    Axis axis;

    
    public OpenGL3(){
        cube = new Cube();
        axis = new Axis();
        
        op.setIdentityMatrix(projMatrix, 4);
        op.setIdentityMatrix(viewMatrix, 4);
        op.setIdentityMatrix(modelMatrix, 4);
        
        /*Altera aki para realizar as transformações*/
        //op.setScaleMatrix(modelMatrix, 1.5f, 1.5f, 1.5f);
        //op.setTranslationMatrix(modelMatrix, 1, 1, 1);
        //op.setRotationMatrix(modelMatrix, 30, 1, 1, 1);
        
        //op.print(mat);
    }
    
    public void setMat(float[] mat){
        this.modelMatrix = mat;  
        //op.print(modelMatrix);
    }
    
    @Override
    public void init(GLAutoDrawable canvas) {
        GL3 gl = canvas.getGL().getGL3();
        gl.glClearColor(0f, 0f, 0f, 0f);
        // Create and compile our GLSL program from the shaders
        createShaders(gl);
        
        gl.glGenVertexArrays(1, vao, 0);
        gl.glBindVertexArray(vao[0]);
        
        FloatBuffer vertexDataBuffer = GLBuffers.newDirectFloatBuffer(cube.getDataCubo());
        gl.glGenBuffers(1, vbo, 0);
        gl.glBindBuffer(GL.GL_ARRAY_BUFFER, vbo[0]);
        gl.glBufferData(GL.GL_ARRAY_BUFFER, Buffers.SIZEOF_FLOAT * vertexDataBuffer.limit(), vertexDataBuffer, GL.GL_STATIC_DRAW);

        // 0=location do atributo no shader
        // penultimo zero pode ser 3 * Float.BYTES
        gl.glVertexAttribPointer(0, 3, GL.GL_FLOAT, false, 6 * Buffers.SIZEOF_FLOAT, 0);// first 0 is the location in shader
        gl.glVertexAttribPointer(1, 3, GL.GL_FLOAT, false, 6 * Buffers.SIZEOF_FLOAT, 3 * Buffers.SIZEOF_FLOAT);
        //gl.glVertexAttribPointer(2, 3, GL.GL_FLOAT, false, 9 * Buffers.SIZEOF_FLOAT, 6 * Buffers.SIZEOF_FLOAT);
        // tem que ativar todos os atributos inicialmente sao desabilitados por padrao
        gl.glEnableVertexAttribArray(0);
        gl.glEnableVertexAttribArray(1);
        gl.glEnableVertexAttribArray(2);
        
        gl.glBindAttribLocation(shaderProgram.program(), 0, "vertexPosition");// name of attribute in shader
        gl.glBindAttribLocation(shaderProgram.program(), 1, "vertexNormal");
        //gl.glBindAttribLocation(shaderProgram.program(), 2, "vertexColor");
        // Note that this is allowed, the call to glVertexAttribPointer registered VBO
        // as the currently bound vertex buffer object so afterwards we can safely unbind
        gl.glBindBuffer(GL.GL_ARRAY_BUFFER, 0);
        // Unbind VAO (it's always a good thing to unbind any buffer/array to prevent strange bugs)
        gl.glBindVertexArray(0);
        
        gl.glUseProgram(shaderProgram.program());

        modelMatrixLoc = gl.glGetUniformLocation(shaderProgram.program(), "modelMatrix");
        viewMatrixLoc = gl.glGetUniformLocation(shaderProgram.program(), "viewMatrix");
        projMatrixLoc = gl.glGetUniformLocation(shaderProgram.program(), "projMatrix");
       
        gl.glUniformMatrix4fv(modelMatrixLoc, 1, false, modelMatrix, 0);
        gl.glUniformMatrix4fv(viewMatrixLoc, 1, false, viewMatrix, 0);
        gl.glUniformMatrix4fv(projMatrixLoc, 1, false, projMatrix, 0);
        
        gl.glBindVertexArray(vao[0]);
        gl.glBindBuffer(GL.GL_ARRAY_BUFFER, vbo[0]);
         gl.glDrawArrays(GL.GL_LINES, 0, 36);
                
        gl.glGenVertexArrays(1, vao, 1);
        gl.glBindVertexArray(vao[1]);
        
        FloatBuffer dataBuffer = GLBuffers.newDirectFloatBuffer(axis.getDataAxis());
        gl.glGenBuffers(1, vbo, 1);
        gl.glBindBuffer(GL.GL_ARRAY_BUFFER, vbo[0]);
        gl.glBufferData(GL.GL_ARRAY_BUFFER, Buffers.SIZEOF_FLOAT * dataBuffer.limit(), dataBuffer, GL.GL_STATIC_DRAW);
        
        gl.glVertexAttribPointer(0, 3, GL.GL_FLOAT, false, 6 * Buffers.SIZEOF_FLOAT, 0);// first 0 is the location in shader
        gl.glVertexAttribPointer(1, 3, GL.GL_FLOAT, false, 6 * Buffers.SIZEOF_FLOAT, 3 * Buffers.SIZEOF_FLOAT);// first 0 is the location in shader
        gl.glVertexAttribPointer(1, 3, GL.GL_FLOAT, false, 9 * Buffers.SIZEOF_FLOAT, 6 * Buffers.SIZEOF_FLOAT);
        
        gl.glEnableVertexAttribArray(0);
        gl.glEnableVertexAttribArray(1);
        //gl.glEnableVertexAttribArray(2);
        
        gl.glBindAttribLocation(shaderProgram.program(), 0, "vertexPosition");// name of attribute in shader
        gl.glBindAttribLocation(shaderProgram.program(), 1, "vertexNormal");
        //gl.glBindAttribLocation(shaderProgram.program(), 2, "vertexColor");
        
        gl.glBindBuffer(GL.GL_ARRAY_BUFFER, 0);
        gl.glBindVertexArray(0);
        
        gl.glUseProgram(shaderProgram.program());

        modelMatrixLoc = gl.glGetUniformLocation(shaderProgram.program(), "modelMatrix");
        viewMatrixLoc = gl.glGetUniformLocation(shaderProgram.program(), "viewMatrix");
        projMatrixLoc = gl.glGetUniformLocation(shaderProgram.program(), "projMatrix");
        
        op.setIdentityMatrix(modelMatrix, 4);
        gl.glUniformMatrix4fv(modelMatrixLoc, 1, false, modelMatrix, 0);
        gl.glUniformMatrix4fv(viewMatrixLoc, 1, false, viewMatrix, 0);
        gl.glUniformMatrix4fv(projMatrixLoc, 1, false, projMatrix, 0);
        
        gl.glBindVertexArray(vao[0]);
        gl.glBindBuffer(GL.GL_ARRAY_BUFFER, vbo[0]);
        gl.glDrawArrays(GL.GL_LINES, 0, 36);
        
    }

    private void createShaders(GL3 gl) {
        vertexShader = ShaderCode.create(gl, GL3.GL_VERTEX_SHADER, getClass(), "shader", null, "opengl", false);
        fragmentShader = ShaderCode.create(gl, GL3.GL_FRAGMENT_SHADER, getClass(), "shader", null, "opengl", false);

        if (!vertexShader.compile(gl, System.err)) {
            throw new GLException("Couldn't compile shader: " + vertexShader);
        }
        if (!fragmentShader.compile(gl, System.err)) {
            throw new GLException("Couldn't compile shader: " + fragmentShader);
        }

        shaderProgram = new ShaderProgram();
        shaderProgram.add(gl, vertexShader, System.err);
        shaderProgram.add(gl, fragmentShader, System.err);
        shaderProgram.link(gl, System.out);
    }

    @Override
    public void display(GLAutoDrawable canvas) {
        GL3 gl = canvas.getGL().getGL3();
        gl.glClear(GL.GL_DEPTH_BUFFER_BIT);// | GL.GL_COLOR_BUFFER_BIT);

        // load everthing back
       /* gl.glUseProgram(shaderProgram.program());
        gl.glBindVertexArray(vao[0]);
        gl.glBindBuffer(GL.GL_ARRAY_BUFFER, vbo[0]);*/
        
/*
        gl.glBindVertexArray(vao[1]);
        gl.glBindBuffer(GL.GL_ARRAY_BUFFER, vbo[1]);
        // Draw our first triangle
        gl.glDrawArrays(GL.GL_LINES, 0, 6);
*/        
        // clean things up
        gl.glUseProgram(0);
    }

    @Override
    public void reshape(GLAutoDrawable canvas, int x, int y, int width, int height) {
        System.out.println("reshape");

        GL3 gl3 = canvas.getGL().getGL3();
        gl3.glViewport(x, y, width, height);
    }

    @Override
    public void dispose(GLAutoDrawable drawable) {
        System.out.println("dispose");

        GL3 gl3 = drawable.getGL().getGL3();
        gl3.glDeleteBuffers(1, vbo, 0);
        gl3.glDeleteVertexArrays(1, vao, 0);

        gl3.glDeleteProgram(shaderProgram.id());
        gl3.glDeleteShader(vertexShader.id());
        gl3.glDeleteShader(fragmentShader.id());
    }

    public static void main(String[] args) {
         Opcoes op = new Opcoes();
        JFrame app = new JFrame("Minimal OpenGL 3 with shader");
        app.setSize(640, 480);
        // this.setResizable(false);
        app.setLocationRelativeTo(null);
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        GLProfile profile = GLProfile.get(GLProfile.GL3);

        GLJPanel canvas = new GLJPanel(new GLCapabilities(profile));
        canvas.addGLEventListener(new OpenGL3());
        app.getContentPane().add(canvas);

        canvas.requestFocusInWindow();
        app.setVisible(true);
        
        op.leitura();
    }
}