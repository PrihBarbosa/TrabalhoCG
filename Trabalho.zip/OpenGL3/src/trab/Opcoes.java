package trab;

import java.util.Scanner;

public class Opcoes {

    public void setIdentityMatrix(float mat[], int size) {
        for (int i = 0; i < size * size; ++i) {
            mat[i] = 0.0f;
        }
        for (int i = 0; i < size; ++i) {
            mat[i + i * size] = 1.0f;
        }
    }

    public void setTranslationMatrix(float mat[], float x, float y, float z) {

        setIdentityMatrix(mat, 4);
        mat[12] = x;
        mat[13] = y;
        mat[14] = z;
    }

    public void setScaleMatrix(float mat[], float x, float y, float z) {
        setIdentityMatrix(mat, 4);
        mat[0] = x;
        mat[5] = y;
        mat[10] = z;
    }

    public void setRotationMatrix(float mat[], float ang, float x, float y, float z) {

        float angle = (float) (ang * Math.PI / 180.0); //converte para grau

        float x2 = x * x;
        float y2 = y * y;
        float z2 = z * z;

        float xy = x * y;
        float xz = x * z;
        float yz = y * z;

        mat[0] = (float) (Math.cos(angle) + (1 - Math.cos(angle)) * x2);
        mat[1] = (float) ((1 - Math.cos(angle)) * xy - (Math.sin(angle)) * z);
        mat[2] = (float) ((1 - Math.cos(angle)) * xz + (Math.sin(angle)) * y);

        mat[4] = (float) ((1 - Math.cos(angle)) * xy + (Math.sin(angle)) * z);
        mat[5] = (float) ((Math.cos(angle)) + (1 - Math.cos(angle)) * y2);
        mat[6] = (float) ((1 - Math.cos(angle)) * yz - (Math.sin(angle)) * x);

        mat[8] = (float) ((1 - Math.cos(angle)) * xz - (Math.sin(angle)) * y);
        mat[9] = (float) ((1 - Math.cos(angle)) * yz + (Math.sin(angle)) * x);
        mat[10] = (float) ((Math.cos(angle)) + (1 - Math.cos(angle)) * z2);

    }

    public void setPerspective(float mat[]) {
        setIdentityMatrix(mat, 4);
        mat[0] = (float) 1 / 2;
        mat[5] = (float) 1 / 2;
        mat[10] = (float) -5 / 3;
        mat[11] = -1;
        mat[14] = (float) -4 / 3;
        mat[15] = 0;

    }

    public void setOrtho(float mat[]) {
        setIdentityMatrix(mat, 4);
        mat[10] = (float) -4 / 3;
        mat[14] = (float) -5 / 3;
    }

    public void print(float[] mat) {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.print(mat[i * 4 + j] + " ");
            }
            System.out.println();;
        }
    }

    public void leitura() {

        String name;
        /*nome usado nos comandos*/
        float x, y, z, ang;
        /*(x,y,z)eixos, (x,y,z)rgb, x(k-coef. de reflexão), ang(ângulo)*/
        float mat[] = new float[16];
        OpenGL3 shape = new OpenGL3();
        Scanner entrada = new Scanner(System.in);
        Opcoes op = new Opcoes();

        System.out.println("Digite seu comando");
        

        /*Leitura dos comandos por linha de comando*/
        /*Irá ler ate não haver mais nada na entrada*/
        while (true) {
            switch (entrada.next()) {
                /*Adiciona a forma correspondente de tamanho centrada na origem com o nome name1 a cena*/
                case "add_shape":
                    switch (entrada.next()) {
                        /*Formas*/
                        case "cube":
                            System.out.println("NOT IMPLEMENTED");
                            break;
                        case "sphere":
                            System.out.println("NOT IMPLEMENTED");
                            break;
                        case "cone":
                            System.out.println("NOT IMPLEMENTED");
                            break;
                        case "torus":
                            System.out.println("NOT IMPLEMENTED");
                            break;
                        default:
                            System.out.println("Você digitou uma opção inválida.");
                    }
                    break;

                /*Remove a forma com o nome name1 da cena*/
                case "remove_shape":
                    name = entrada.next();
                    System.out.println("NOT IMPLEMENTED");
                    break;

                /*Adiciona uma nova luz na posição(x,y,z) na cena. Máximo 10*/
                case "add_light":
                    name = entrada.next();
                    x = Float.parseFloat(entrada.next());
                    y = Float.parseFloat(entrada.next());
                    z = Float.parseFloat(entrada.next());
                    System.out.println("NOT IMPLEMENTED");
                    break;

                /*Remove a luz com o nome name1 da cena*/
                case "remove_light":
                    name = entrada.next();
                    System.out.println("NOT IMPLEMENTED");
                    break;

                /*Habilita o tipo de reflexão da luz nos objetos da cena e define o coeficiente de reflexão associado (k).
                      Coeficiente  de  brilho  da  reflexão  especular  fixo*/
                case "reflection_on":
                    switch (entrada.next()) {
                        /*x = (k - coef. de reflexão)*/
                        /*Tipos de reflexão*/
                        case "specular":
                            x = Float.parseFloat(entrada.next());
                            System.out.println("NOT IMPLEMENTED");
                            break;
                        case "diffuse":
                            x = Float.parseFloat(entrada.next());
                            System.out.println("NOT IMPLEMENTED");
                            break;
                        case "ambiente":
                            x = Float.parseFloat(entrada.next());
                            System.out.println("NOT IMPLEMENTED");
                            break;
                        default:
                            System.out.println("Você digitou uma opção inválida.");
                    }
                    break;

                /*Desabilita o tipo de reflexão da luz nos objetos da cena*/
                case "reflection_off":
                    switch (entrada.next()) {
                        /*Tipos de reflexão*/
                        case "specular":
                            System.out.println("NOT IMPLEMENTED");
                            break;
                        case "diffuse":
                            System.out.println("NOT IMPLEMENTED");
                            break;
                        case "ambiente":
                            System.out.println("NOT IMPLEMENTED");
                            break;
                        default:
                            System.out.println("Você digitou uma opção inválida.");
                    }
                    break;

                /*Define o tipo de shading usado para renderizar a cena*/
                case "shading":
                    switch (entrada.next()) {
                        /*Tipos de shading*/
                        case "flat":
                            System.out.println("NOT IMPLEMENTED");
                            break;
                        case "smooth":
                            System.out.println("NOT IMPLEMENTED");
                            break;
                        case "ephong":
                            System.out.println("NOT IMPLEMENTED");
                            break;
                        default:
                            System.out.println("Você digitou uma opção inválida.");
                    }
                    break;

                /*Define o tipo de projeção.Tamanho do fruentradaum fixo*/
                case "projection":
                    switch (entrada.next()) {
                        /*Tipos*/
                        case "ortho":
                            System.out.println("NOT IMPLEMENTED");
                            break;
                        case "perspective":
                            System.out.println("NOT IMPLEMENTED");
                            break;
                        default:
                            System.out.println("Você digitou uma opção inválida.");
                    }
                    break;

                /*Translada a forma correspondente de acordo com os três parâmetros em (x, y, z)*/
                case "translate":

                    name = entrada.next();
                    x = Float.parseFloat(entrada.next());
                    y = Float.parseFloat(entrada.next());
                    z = Float.parseFloat(entrada.next());
                    setTranslationMatrix(mat, x, y, z);
                    //print(mat);
                    //enviar mat pro shape
                    shape.setMat(mat);

                    break;

                /*Redimensiona a forma correspondente de acordo com os três parâmetros em (x, y, z)*/
                case "scale":
                    name = entrada.next();
                    x = Float.parseFloat(entrada.next());
                    y = Float.parseFloat(entrada.next());
                    z = Float.parseFloat(entrada.next());
                    
                    setScaleMatrix(mat, x, y, z);
                    shape.setMat(mat);
                    //print(mat);
                    break;

                /*Rotaciona a forma correspondente de acordo com o ângulo e o vetor (x, y, z)*/
                case "rotate":
                    name = entrada.next();
                    ang = Float.parseFloat(entrada.next());
                    x = Float.parseFloat(entrada.next());
                    y = Float.parseFloat(entrada.next());
                    z = Float.parseFloat(entrada.next());
                    shape.setMat(mat);
                    setRotationMatrix(mat, ang, x, y, z);
                    //print(mat);
                    break;

                /*Faz a câmera olhar para o ponto definido pelos parâmetros (x,y,z).*/
                case "lookate":
                    x = Float.parseFloat(entrada.next());
                    y = Float.parseFloat(entrada.next());
                    z = Float.parseFloat(entrada.next());
                    System.out.println("NOT IMPLEMENTED");
                    break;

                /*Define a posição da câmera por meio dos parâmetros (x,y,z)*/
                case "cam":
                    x = Float.parseFloat(entrada.next());
                    y = Float.parseFloat(entrada.next());
                    z = Float.parseFloat(entrada.next());
                    System.out.println("NOT IMPLEMENTED");
                    break;

                /*Define a cor da forma com nome name1 usando três parâmetros (r, g, b).*/
                case "color":
                    /*(x,y,z) = rgb*/
                    name = entrada.next();
                    x = Float.parseFloat(entrada.next());
                    y = Float.parseFloat(entrada.next());
                    z = Float.parseFloat(entrada.next());
                    System.out.println("NOT IMPLEMENTED");
                    break;

                /*Moentradara ou esconde os eixos x, y e z. Eixo x vermelho, y verde e z azul*/
                case "axis":
                    break;

                /*Salva a visualização corrente em uma imagem png com o nome filename*/
                case "save":
                    name = entrada.next();
                    System.out.println("NOT IMPLEMENTED");
                    break;

                /*Sai do programa*/
                case "quit":
                    System.exit(0);
                    break;

                default:
                    System.out.println("Você digitou uma operação inválida.");

            }
        }
       
    }

}
